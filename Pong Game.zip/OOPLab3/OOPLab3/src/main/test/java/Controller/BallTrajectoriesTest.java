package Controller;

import org.junit.jupiter.api.Test;
import Model.Game;
import myMenu.myCanvas;

import static org.junit.jupiter.api.Assertions.*;

class BallTrajectoriesTest {
    Game testGame = new Game();
    myCanvas testCanvas = new myCanvas(600,600);
    BallTrajectories testBall = new BallTrajectories(testGame,testCanvas, null,null);

    @Test
    void testEdgeCollide(){
        testGame.getBall().setBallPosY(0);

        assertTrue(testBall.edgeCollision(testGame));
    }

    @Test
    void testNoEdgeCollide(){
        testGame.getBall().setBallPosY(100);

        assertFalse(testBall.edgeCollision(testGame));
    }

    @Test
    void testRacketCollide(){
        testGame.getBall().setBallPosY(150);
        testGame.getBall().setBallPosX(20);

        assertTrue(testBall.racketP1Collision(testGame));
    }

    @Test
    void testNoRacketCollide(){
        testGame.getBall().setBallPosY(300);
        testGame.getBall().setBallPosX(300);

        assertFalse(testBall.racketP1Collision(testGame));
    }


}