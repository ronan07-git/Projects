package com.example.ooplab3;

import Controller.Controller;
import SerialService.Service;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import myMenu.myMenu;
import myMenu.myCanvas;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import Controller.BallTrajectories;
import Model.Game;
import DAO.pongDAO;

import java.security.Key;
import java.util.Optional;
import Controller.KeyboardListen;

public class HelloApplication extends Application {
    // Variable Creation
    private myMenu myMenu = new myMenu();
    private myCanvas myCanvas = new myCanvas(1280,700);
    private Controller controller = new Controller();
    pongDAO pongDAO = new pongDAO();


    /**
     * Main Body of Application which will run when we execute our program.
     * @param primaryStage
     * @throws Exception
     */
    public void start(Stage primaryStage) throws Exception {

        //Creation of Stage
        primaryStage.setTitle("Pong");
        primaryStage.setResizable(true);
        primaryStage.widthProperty().addListener((obs, prevDimX, newDimX) -> {

            if (prevDimX == null || prevDimX.doubleValue() <= 0) return;

            double factor = newDimX.doubleValue() / prevDimX.doubleValue();

            if (Double.isNaN(factor) || Double.isInfinite(factor)) return;

            controller.getGame().setDimX(newDimX.doubleValue());
            controller.getGame().resizeWidth(factor);

            myCanvas.setWidth(newDimX.doubleValue());
            myCanvas.reCanvas();
        });

        primaryStage.heightProperty().addListener((obs, oldDimY, newDimY) -> {

            if (oldDimY == null || oldDimY.doubleValue() <= 0) return;

            double factor = newDimY.doubleValue() / oldDimY.doubleValue();

            if (Double.isNaN(factor) || Double.isInfinite(factor)) return;

            controller.getGame().resizeHeight(factor);
            controller.getGame().setDimY(newDimY.doubleValue());

            myCanvas.setHeight(newDimY.doubleValue());
            myCanvas.reCanvas();
        });

        // Creating the score text
        Text score = new Text();
        score.setFill(Color.BLACK);
        score.setStyle("-fx-font-size: 24;");

        // Creating the player's usernames
        Text usernames = new Text();
        usernames.setFill(Color.BLACK);
        usernames.setStyle("-fx-font-size: 24;");

        // Creating the text for when a player scores a goal
        Text scored = new Text();
        scored.setFill(Color.BLACK);
        scored.setStyle("-fx-font-size: 24;");
        scored.setVisible(false);

        //A method which prompts the user to input the usernames of the players, functions similar to simpledialog in python
        TextInputDialog input = new TextInputDialog();
        input.setHeaderText("Name One: ");
        Optional<String> entry = input.showAndWait();
        entry.ifPresent(name -> controller.getGame().getPlayerOne().setPlayerUserName(name));


        TextInputDialog input2 = new TextInputDialog();
        input2.setHeaderText("Name Two: ");
        Optional<String> entry2 = input2.showAndWait();
        entry2.ifPresent(name ->
                controller.getGame().getPlayerTwo().setPlayerUserName(name)
        );

        // Sets the usernames inputted
        usernames.setText(
                controller.getGame().getPlayerOne().getPlayerUserName() + " VS " + controller.getGame().getPlayerTwo().getPlayerUserName()
        );

        // Sets the score between players
        score.setText(
                controller.getGame().getPlayerOne().getPlayerScore() + " - " + controller.getGame().getPlayerTwo().getPlayerScore()
        );


        // Exit button
        myMenu.getMenuItemExit().setOnAction(e -> Platform.exit());

        //Set the menu at the top of the screen
        BorderPane root = new BorderPane();
        root.setTop(myMenu.getMenuBar());



        // Creating the game
        StackPane centerPane = new StackPane();
        centerPane.getChildren().addAll(myCanvas, usernames, score, scored);
        root.setCenter(centerPane);
        StackPane.setAlignment(usernames, Pos.TOP_CENTER);
        StackPane.setAlignment(score, Pos.BOTTOM_CENTER);
        StackPane.setAlignment(scored, Pos.CENTER);
        myCanvas.setGame(controller.getGame());
        myCanvas.reCanvas();

        BallTrajectories ballTrajectories = new BallTrajectories(controller.getGame(), myCanvas, score, scored);
        Thread ballThread = new Thread(ballTrajectories);
        ballThread.start();
        Thread.yield();

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        KeyboardListen keyListener = new KeyboardListen(controller.getGame(), myCanvas, ballTrajectories);
        scene.setOnKeyPressed(keyListener);

        primaryStage.show();

        myMenu.getSaveGameState().setOnAction(event -> {
            Service.getInstance().saveState(controller.getGame());
            pongDAO.fullSave(controller.getGame());
        });

        myMenu.getLoadGameState().setOnAction(event -> {
            Game retrieved = pongDAO.loadSave();


            if (retrieved != null) {

                controller.loadGame(
                        retrieved,
                        myCanvas.getWidth(),
                        myCanvas.getHeight()
                );

                myCanvas.setGame(controller.getGame());

                ballTrajectories.setGame(controller.getGame());
                ballTrajectories.resumeState();

                keyListener.setGame(controller.getGame());

                myCanvas.setGame(controller.getGame());
                ballTrajectories.setGame(controller.getGame());


                score.setText(
                        controller.getGame().getPlayerOne().getPlayerScore() + " - " +
                                controller.getGame().getPlayerTwo().getPlayerScore()
                );

                usernames.setText(
                        controller.getGame().getPlayerOne().getPlayerUserName() + " VS " + controller.getGame().getPlayerTwo().getPlayerUserName()
                );

                System.out.println("Loaded Previous Save");
                myCanvas.reCanvas();
            }

        });
    }

}
