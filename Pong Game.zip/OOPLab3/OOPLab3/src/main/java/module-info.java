module com.example.ooplab3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires java.sql;


    opens com.example.ooplab3 to javafx.fxml;
    exports com.example.ooplab3;
    exports Controller;
    exports DAO;
    exports Model;
    exports myMenu;
    exports SerialService;
    exports HeapStackExperiment;
    exports Build;
}