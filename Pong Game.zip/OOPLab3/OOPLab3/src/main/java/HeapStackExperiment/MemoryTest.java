package HeapStackExperiment;

import java.util.ArrayList;

public class MemoryTest {
    int stackHeight = 0;

    /**
     * Recursive method for stackTests
     */
    public void recursion(){
        stackHeight++;
        recursion();
    }

    /**
     * Heap Stack Method which tests the time of object allocations before failure.
     */
    public void heapExperiment(){
        ArrayList<long[]> memoryArray = new ArrayList<>();

        byte[] backupMemory = new byte[10 * 1024 * 1024];

        int objectsMade = 0;
        long start = System.currentTimeMillis();

        try {
            while (true){
                memoryArray.add(new long[50000]);
                objectsMade++;

                if(objectsMade % 25 == 0){
                    long currentTime = System.currentTimeMillis();
                    double seconds = (currentTime -  start) / 1000.0;

                    System.out.println("O: " + objectsMade + " M: " + seconds);
                }
            }
        } catch (OutOfMemoryError e) {
            backupMemory = null;
            memoryArray = null;
            System.gc();

            long exitTime = System.currentTimeMillis();
            double seconds = (exitTime - start) / 1000.0;

            System.out.println("Heap test completed");
            System.out.println("Objects made: " + objectsMade);
            System.out.println("Time elapsed: " + seconds + " seconds");
        }
    }

    /**
     * Stack method which tests the amount of recursive distance/depth it can make before failure.
     */
    public void stackExperiment(){

        stackHeight = 0;
        long start = System.currentTimeMillis();


        try{
            recursion();
        } catch (StackOverflowError e){
            long exitTime = System.currentTimeMillis();
            double secondsTime =  (exitTime - start) /  1000.0;

            System.out.println("Test completed: " + stackHeight + " height created within " + secondsTime + " seconds");
        }
    }


}
