package HeapStackExperiment;

public class runTest {
    /**
     * Isolated testing class for HeapStackExperiments
     * @param args
     */
    public static void main(String[] args) {
        MemoryTest memoryTest = new MemoryTest();

        memoryTest.stackExperiment();
    }
}
