package Model;

/**
 * Resize Window Interface
 */
public interface resizeable {
    public void resizeWidth(double factor);
    public void resizeHeight(double factor);
}
