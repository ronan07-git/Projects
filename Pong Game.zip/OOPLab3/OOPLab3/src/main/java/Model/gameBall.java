package Model;

import java.io.Serializable;


public class gameBall implements Serializable {

    // Variable Creation
    private double ballPosX;
    private double ballPosY;
    private double ballDimensionA;
    private double ballDimensionB;
    private double velX;
    private double velY;


    /**
     * Constructor method
     * @param ballPosX
     * @param ballPosY
     */
    public gameBall(double ballPosX, double ballPosY) {
        this.ballPosX = ballPosX;
        this.ballPosY = ballPosY;
    }

    /**
     * Method for ball movement
     */

    public void moveBall(){
        ballPosX += velX;
        ballPosY += velY;
    }


    // Getter and Setters

    /**
     * Getter and Setters
     * @return
     */
    public double getBallPosX() {
        return ballPosX;
    }

    public void setBallPosX(double ballPosX) {
        this.ballPosX = ballPosX;
    }

    public double getBallPosY() {
        return ballPosY;
    }

    public void setBallPosY(double ballPosY) {
        this.ballPosY = ballPosY;
    }

    public double getBallDimensionA() {
        return ballDimensionA;
    }

    public void setBallDimensionA(double ballDimensionA) {
        this.ballDimensionA = ballDimensionA;
    }

    public double getBallDimensionB() {
        return ballDimensionB;
    }

    public void setBallDimensionB(double ballDimensionB) {
        this.ballDimensionB = ballDimensionB;
    }

    public double getVelX() {
        return velX;
    }

    public void setVelX(double velX) {
        this.velX = velX;
    }

    public double getVelY() {
        return velY;
    }

    public void setVelY(double velY) {
        this.velY = velY;
    }

    /**
     *  Resizable Window
     */

    public void resizeWidth(double factor) {
       ballPosX *= factor;
       ballDimensionA *= factor;
    }

    public void resizeHeight(double factor) {
        ballPosY *= factor;
        ballDimensionB *= factor;
    }
}
