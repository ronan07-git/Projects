package Model;

import java.io.Serializable;

public class gamePlayer implements Serializable {

    // Variable Creation
    private String playerUserName;
    private int playerScore;
    private gameRackets racket;

    /**
     * Constructor Method
     * @param playerUserName
     * @param playerScore
     */
    public gamePlayer(String playerUserName, int playerScore) {
        this.playerUserName = playerUserName;
        this.playerScore = 0;

        racket = new gameRackets(10,80,0,0);
    }

    /**
     * Getters and Setters
     * @return
     */
    public String getPlayerUserName() {
        return playerUserName;
    }

    public void setPlayerUserName(String playerUserName) {
        this.playerUserName = playerUserName;
    }

    public int getPlayerScore() {
        return playerScore;
    }

    public void setPlayerScore(int playerScore) {
        this.playerScore = playerScore;
    }

    public void scorePoint(){
        playerScore += 1;
    }

    public void reset(){
        playerScore = 0;
    }

    public gameRackets getRacket() {
        return racket;
    }

}
