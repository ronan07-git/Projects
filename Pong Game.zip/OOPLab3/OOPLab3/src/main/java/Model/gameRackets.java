package Model;

import java.io.Serializable;

public class gameRackets extends PosAndSpeed implements Serializable{

    // Variable Creation
    private double racketWidth;
    private double racketHeight;

    public gameRackets(double racketWidth,double racketHeight, double posX,double posY) {
        this.racketWidth = racketWidth;
        this.racketHeight = racketHeight;
        this.posX = posX;
        this.posY = posY;
    }


    /**
     * Getters and Setters
     * @return
     */
    public double getRacketWidth() {
        return racketWidth;
    }

    public void setRacketWidth(double racketWidth) {
        this.racketWidth = racketWidth;
    }

    public double getRacketHeight() {
        return racketHeight;
    }

    public void setRacketHeight(double racketHeight) {
        this.racketHeight = racketHeight;
    }

    public void moveUp(){
        posY -= 10;
    }

    public void moveDown(){
        posY += 10;
    }

    /**
     * Resizable Window
     * @param factor
     */

    public void resizeWidth(double factor) {

        if (Double.isNaN(posX) || Double.isInfinite(posX)) posX = 0;

        posX *= factor;
        racketWidth *= factor;
    }

    public void resizeHeight(double factor) {

        if (Double.isNaN(posY) || Double.isInfinite(posY)) posY = 0;

        posY *= factor;
        racketHeight *= factor;
    }
}
