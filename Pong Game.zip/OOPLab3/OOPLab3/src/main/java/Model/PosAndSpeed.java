package Model;

import java.io.Serializable;

public class PosAndSpeed implements Serializable {
    // Variable Creation
    double posX;
    double posY;
    double velX;
    double velY;


    /**
     *     Getters and Setters
     */

    public double getVelY() {
        return velY;
    }

    public void setVelY(double velY) {
        this.velY = velY;
    }

    public double getVelX() {
        return velX;
    }

    public void setVelX(double velX) {
        this.velX = velX;
    }

    public double getPosY() {
        return posY;
    }

    public void setPosY(double posY) {
        this.posY = posY;
    }

    public double getPosX() {
        return posX;
    }

    public void setPosX(double posX) {
        this.posX = posX;
    }
}
