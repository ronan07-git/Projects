package Model;

import Model.gameRackets;
import java.io.Serializable;

public class Game implements Serializable{

    // Creating Variables

    private gamePlayer playerOne;
    private gamePlayer playerTwo;
    private gameBall ball;

    private int matchScore = 3;

    private double dimX = 1280;
    private double dimY = 720;


    /**
     * Constructor Method
     */
    public Game(){
        playerOne = new gamePlayer("User 1", 0);
        playerTwo = new gamePlayer("User 2", 0);

        playerOne.getRacket().setPosX(20);
        playerOne.getRacket().setPosY(150);

        playerTwo.getRacket().setPosX(dimX - 30);
        playerTwo.getRacket().setPosY(150);


        ball = new gameBall(300,200);
        ball.setBallDimensionA(20);
        ball.setBallDimensionB(20);


        ball.setVelX(2);
        ball.setVelY(2);

    }


    /**
     *     Getters and Setters
      */
    public gamePlayer getPlayerOne() {
        return playerOne;
    }

    public gamePlayer getPlayerTwo() {
        return playerTwo;
    }


    public gameBall getBall() {
        return ball;
    }

    public double getDimX() {
        return dimX;
    }

    public double getDimY() {
        return dimY;
    }

    public void setDimX(double dimX) {
        this.dimX = dimX;
    }

    public void setDimY(double dimY) {
        this.dimY = dimY;
    }

    public int getMatchScore(){
        return matchScore;
    }

    public void setMatchScore(int matchScore) {
        this.matchScore = matchScore;
    }

    /**
     *     Method which when the winning score is met the game announces the winner
     */
    public String gameOver(){
        if (playerOne.getPlayerScore() == matchScore){
            return playerOne.getPlayerUserName() + " wins!";
        }

        if (playerTwo.getPlayerScore() == matchScore){
            return playerTwo.getPlayerUserName() + " wins!";
        }

        return null;
    }


    /**
     *     Resizable Window
     */

    public void resizeWidth(double factor) {
        playerOne.getRacket().resizeWidth(factor);
        playerTwo.getRacket().resizeWidth(factor);
        ball.resizeWidth(factor);

        double offsetRight = dimX - playerTwo.getRacket().getPosX();

        playerTwo.getRacket().setPosX(dimX - offsetRight * factor);
    }

    public void resizeHeight(double factor) {
        playerOne.getRacket().resizeHeight(factor);
        playerTwo.getRacket().resizeHeight(factor);
        ball.resizeHeight(factor);

    }

}
