package myMenu;

import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.*;

public class myMenu {

    // Variable Creation
    private MenuBar menuBar;
    private Menu menuFile;
    private Menu menuHelp;
    private MenuItem saveGameState;
    private MenuItem loadGameState;
    private MenuItem menuItemExit;
    private MenuItem menuItemAbout;

    //Menu Set up
    public myMenu() {
        menuBar = new MenuBar();
        menuFile = new Menu("File");
        menuHelp = new Menu("Help");
        menuItemExit = new MenuItem("Exit");
        menuItemAbout = new MenuItem("About");
        saveGameState = new MenuItem("Save Game");
        loadGameState = new MenuItem("Load Game");
        menuFile.getItems().addAll(saveGameState, loadGameState, menuItemExit);
        menuHelp.getItems().add(menuItemAbout);
        menuBar.getMenus().addAll(menuFile, menuHelp);
    }

    // Getter and Setter methods
    public MenuBar getMenuBar() {
        return menuBar;
    }

    public void setMenuBar(MenuBar menuBar) {
        this.menuBar = menuBar;
    }

    public Menu getMenuFile() {
        return menuFile;
    }

    public void setMenuFile(Menu menuFile) {
        this.menuFile = menuFile;
    }

    public Menu getMenuHelp() {
        return menuHelp;
    }

    public void setMenuHelp(Menu menuHelp) {
        this.menuHelp = menuHelp;
    }

    public MenuItem getMenuItemExit() {
        return menuItemExit;
    }

    public void setMenuItemExit(MenuItem menuItemExit) {
        this.menuItemExit = menuItemExit;
    }

    public MenuItem getMenuItemAbout() {
        return menuItemAbout;
    }

    public void setMenuItemAbout(MenuItem menuItemAbout) {
        this.menuItemAbout = menuItemAbout;
    }

    public MenuItem getSaveGameState() {
        return saveGameState;
    }

    public void setSaveGameState(MenuItem saveGameState) {
        this.saveGameState = saveGameState;
    }

    public MenuItem getLoadGameState() {
        return loadGameState;
    }

    public void setLoadGameState(MenuItem loadGameState) {
        this.loadGameState = loadGameState;
    }
}


