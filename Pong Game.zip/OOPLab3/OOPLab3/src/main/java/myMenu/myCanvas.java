package myMenu;

import Model.Game;
import Model.gameBall;
import Model.gameRackets;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class myCanvas extends Canvas {
    //Variable Creation
    private Game game;

    /**
     * Constructor Method
     * @param width
     * @param height
     */
    public myCanvas(double width, double height) {
        super(width,height);
    }

    /**
     * Method which creates a visible ball object on the stage.
     * @param gc
     */
    public void drawBall(GraphicsContext gc) {
        gameBall ball = game.getBall();

        gc.setFill(Color.RED);
        gc.fillOval(ball.getBallPosX(),ball.getBallPosY(),ball.getBallDimensionA(),ball.getBallDimensionB());
    }

    /**
     * Method which creates visible rackets on the stage.
     * @param gc
     */
    public void drawRacket(GraphicsContext gc ) {
        gameRackets racketOne = game.getPlayerOne().getRacket();
        gameRackets racketTwo = game.getPlayerTwo().getRacket();

        gc.setFill(Color.YELLOW);
        gc.fillRect(racketOne.getPosX(),racketOne.getPosY(),racketOne.getRacketWidth(),racketOne.getRacketHeight());

        gc.setFill(Color.GREEN);
        gc.fillRect(racketTwo.getPosX(),racketTwo.getPosY(),racketTwo.getRacketWidth(),racketTwo.getRacketHeight());


        /**
         * Debugging method for racket positions
         * System.out.println("R1: " + racketOne.getPosX() + "," + racketOne.getPosY());
         * System.out.println("R2: " + racketTwo.getPosX() + "," + racketTwo.getPosY());
          */
    }

    /**
     * Method which creates the stage background.
     * @param gc
     */
    public void drawBackground(GraphicsContext gc) {
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, getWidth(), getHeight());
    }

    /**
     * Setter method
     * @param game
     */
    public void setGame(Game game) {
        this.game = game;
        reCanvas();
    }

    /**
     * Method which initializes the overall/general canvas using the GC methods.
     */
    public void reCanvas(){
        resize(getWidth(),getHeight());
        GraphicsContext gc = this.getGraphicsContext2D();
        drawBackground(gc);
        drawBall(gc);
        drawRacket(gc);
    }


}
