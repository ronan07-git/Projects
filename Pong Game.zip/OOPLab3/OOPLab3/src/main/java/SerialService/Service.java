package SerialService;

import Model.Game;
import javafx.scene.control.Alert;
import java.io.*;

public class Service {
    private static Service instance;

    private Service () {}

    /**
     * Error Alert Method
     * @param errorMessage
     */
    public void errorNotif(String errorMessage){
        Alert alertNotif = new Alert(Alert.AlertType.ERROR);
        alertNotif.setTitle("Program Error");
        alertNotif.setHeaderText(null);
        alertNotif.setContentText(errorMessage);
        alertNotif.showAndWait();
    }

    /**
     * Getter Method
     * @return
     */
    public static Service getInstance() {
        if (instance == null) {
            instance = new Service();
        }
        return instance;
    }

    /**
     * Converts and saves current game data to a file.
     * @param game
     */
    public void saveState(Game game){
        try(ObjectOutputStream dataOut = new ObjectOutputStream(new FileOutputStream("gameStateInfo.dat"))){
            dataOut.writeObject(game);
        } catch (IOException e) {
            errorNotif("Error saving gameStateInfo.dat");
        }
    }

    /**
     * Getter Method / Retrieves Serialized Game data.
     * @return
     */
    public Game retrieveState(){
        try(ObjectInputStream dataIn = new ObjectInputStream(new FileInputStream("gameStateInfo.dat"))) {
            return (Game) dataIn.readObject();
        } catch (Exception e) {
            errorNotif("Error retrieving gameStateInfo.dat");
        }
        return null;
    }
}
