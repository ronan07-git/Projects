package Controller;

import com.example.ooplab3.HelloController;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import Model.Game;
import Controller.BallTrajectories;
import myMenu.myCanvas;


public class KeyboardListen implements EventHandler<KeyEvent>{

    // Variable Creation
    private Game game;
    private myCanvas canvas;
    private BallTrajectories ballTraject;


    /**
     * Constructor method
     * @param game
     * @param canvas
     * @param ballTraject
     */
    public KeyboardListen(Game game, myCanvas canvas, BallTrajectories ballTraject){
        this.game = game;
        this.canvas = canvas;
        this.ballTraject = ballTraject;
    }

    public void setGame(Game game){
        this.game = game;
    }

    /**
     * Method for reading keyboard input.
     * @param keyEvent
     */
    public void handle(KeyEvent keyEvent) {
        if (keyEvent.getCode() == KeyCode.W) {
            if (!ballTraject.getState()){
                game.getPlayerOne().getRacket().moveUp();
            }
        }

        if (keyEvent.getCode() == KeyCode.S){
            if (!ballTraject.getState()){
                game.getPlayerOne().getRacket().moveDown();
            }
        }

        if (keyEvent.getCode() == KeyCode.UP){
            if (!ballTraject.getState()){
                game.getPlayerTwo().getRacket().moveUp();
            }
        }

        if (keyEvent.getCode() == KeyCode.DOWN){
            if(!ballTraject.getState()){
                game.getPlayerTwo().getRacket().moveDown();
            }
        }

        if (keyEvent.getCode() == KeyCode.ESCAPE){
            ballTraject.pauseGame();
        }

        if (keyEvent.getCode() == KeyCode.R){
            if (ballTraject.getState()){
                ballTraject.restart();
            }
        }

        canvas.reCanvas();
    }
}
