package Controller;


import Model.Game;

public class Controller {

    /**
     * Method which recreates the game window and ball.
     * @param loaded
     * @param width
     * @param height
     */

    public void loadGame(Game loaded, double width, double height) {

        if (loaded == null) return;

        double factorX = width / loaded.getDimX();
        double factorY = height / loaded.getDimY();

        loaded.resizeWidth(factorX);
        loaded.resizeHeight(factorY);

        loaded.setDimX(width);
        loaded.setDimY(height);

        loaded.getBall().setBallPosX(width / 2);
        loaded.getBall().setBallPosY(height / 2);

        loaded.getBall().setBallDimensionA(20);
        loaded.getBall().setBallDimensionB(20);

        loaded.getBall().setVelX(2);
        loaded.getBall().setVelY(2);

        this.game = loaded;
    }

    // Variable creation
    public Game game;

    /**
     *     Constructor method
      */
    public Controller() {
        game = new Game();
    }

    /**
     *     Getter method
      */
    public Game getGame() {
        return game;
    }

    /**
     *     Sets the assigned player names
     */
    public void setPlayerName(String playerName1, String playerName2) {
        game.getPlayerOne().setPlayerUserName(playerName1);
        game.getPlayerTwo().setPlayerUserName(playerName2);
    }

    /**
     * Game Setter
     * @param game
     */
    public void setGame(Game game) {
        this.game = game;
    }

    /**
     * Sets the balls velocity
     * @param velocity
     */
    public void setBallVelocity(double velocity){
        game.getBall().setVelX(velocity);
        game.getBall().setVelY(velocity);
    }

    /**
     * Sets the rackets sizes
     * @param size
     */
    public void setRackets(double size){
        game.getPlayerOne().getRacket().setRacketHeight(size);
        game.getPlayerTwo().getRacket().setRacketHeight(size);
    }

}
