package Controller;

import Model.Game;
import Model.gameBall;
import Model.gameRackets;
import Model.*;
import javafx.animation.PauseTransition;
import javafx.scene.text.Text;
import javafx.util.Duration;
import myMenu.myCanvas;
import javafx.application.Platform;
import java.math.*;
import DAO.pongDAO;

public class BallTrajectories implements Runnable{

    /**
     *     Variable Creation
     */
    private Game game;
    private myCanvas canvas;
    private Text score;
    private Text scored;
    private volatile boolean onPause = false;
    pongDAO pongDAO = new pongDAO();


    /**
     *     Constructor Method
     */

    public BallTrajectories(Game game, myCanvas canvas, Text score, Text scored){
        this.game = game;
        this.canvas = canvas;
        this.score = score;
        this.scored = scored;
    }

    /**
     * Method which resets the balls position back to its starting position
     */
    private void resetPos(){
        game.getBall().setBallPosX(game.getDimX()/2);
        game.getBall().setBallPosY(game.getDimY()/2);
    }


    /**
     *Condensed Goal Message Method to reduce amount of code when reading the run function.
     */
    private void displayScored(String scoreText){
        Platform.runLater(()->{
            scored.setText(scoreText);
            scored.setVisible(true);
            PauseTransition stagger = new PauseTransition(Duration.seconds(3));
            stagger.setOnFinished((x -> {
                scored.setVisible(false);
            }));
           stagger.play();
        });
    }


    /**
     * Change game state from pause to paused.
     */
    public void pauseGame(){

        onPause = !onPause;
    }

    /**
     * Get game state
     * @return
     */
    public boolean getState(){
        return onPause;
    }

    /**
     * Resume game.
     */
    public void resumeState(){
        onPause = false;
    }

    /**
     *     Restarts the game by wiping the players scores.
      */
    public void restart(){
        Platform.runLater(()->{
            scored.setText("GAME RESET: O - O");
            scored.setVisible(true);
            PauseTransition stagger = new PauseTransition(Duration.seconds(2));
            stagger.setOnFinished((x -> {
                scored.setVisible(false);
            }));
            stagger.play();
        });
        game.getPlayerOne().setPlayerScore(0);
        game.getPlayerTwo().setPlayerScore(0);
        score.setText(game.getPlayerOne().getPlayerScore() + " - " + game.getPlayerTwo().getPlayerScore());
    }

    /**
     * Sets the game.
     * @param game
     */
    public void setGame(Game game){
        this.game = game;
    }

    /**
     * Returns when the ball hits the edge (Debugging method)
     * @param game
     * @return
     */
    public boolean edgeCollision(Game game) {
        return game.getBall().getBallPosY() <= 0 || game.getBall().getBallPosY() + game.getBall().getBallDimensionB() >= game.getDimY();
    }

    /**
     * Returns when ball hits a racket (Debugging method)
     * @param game
     * @return
     */
    public boolean racketP1Collision(Game game){
        var ball = game.getBall();
        var racket = game.getPlayerOne().getRacket();

        double leftSide = ball.getBallPosX();
        double rightSide = ball.getBallPosX() + ball.getBallDimensionA();
        double topSide = ball.getBallPosY();
        double bottomSide = ball.getBallPosY() + ball.getBallDimensionB();

        return leftSide <= racket.getPosX() + racket.getRacketWidth() && rightSide >= racket.getPosX() && topSide <= racket.getPosY() + racket.getRacketHeight() && bottomSide >= racket.getPosY();

    }

    @Override
    /**
     * Main loop of the program, intializes a infinite loop to start and run the game until the break condition is met.
     */
    public void run() {


        while (true) {

            /**
             * Create/Get the ball for the game.
             */
            gameBall ball = game.getBall();

            try {
                Thread.sleep(20);
            } catch (Exception exception) {
                throw new RuntimeException(exception);
            }

            /**
             * If the game is paused, display a paused message and ignore all the code which comes after it AKA pause game.
             */
            if(onPause){
                Platform.runLater(()->{
                    score.setText("PAUSED");
                    score.setVisible(true);
                });
                continue;
            }
            else {
                Platform.runLater(()->{
                    score.setText(game.getPlayerOne().getPlayerScore() + " - " + game.getPlayerTwo().getPlayerScore());
                });
            }

            /**
             *   Collision detectors for the edges of the window.
             */
            if(ball.getBallPosY() <= 0){
                ball.setVelY(-ball.getVelY());
            }

            if(ball.getBallPosY() + ball.getBallDimensionB() >= game.getDimY()){
                ball.setVelY(-ball.getVelY());
            }


            /**
             * Player Two Goal/Score event. If the balls position on the X axis is less or equal to 0 (hits the edge behind the other player),
             *  then Player two has scored a goal and receives a point while the balls velocity and position is reset
              */
            if(ball.getBallPosX() <= 0){
                game.getPlayerTwo().scorePoint();

                resetPos();
                ball.setVelX(2);
                ball.setVelY(2);

                displayScored("SCORE " + game.getPlayerTwo().getPlayerUserName());

                Platform.runLater(() -> {
                    score.setText(game.getPlayerOne().getPlayerScore() + " - " + game.getPlayerTwo().getPlayerScore());
                });
            }

            if (ball.getBallPosX() >= game.getDimX() - ball.getBallDimensionA()){
                game.getPlayerOne().scorePoint();

                resetPos();
                ball.setVelX(2);
                ball.setVelY(2);

                displayScored("SCORE " + game.getPlayerOne().getPlayerUserName());

                Platform.runLater(() -> {
                    score.setText(
                            game.getPlayerOne().getPlayerScore() + " - " + game.getPlayerTwo().getPlayerScore()
                    );
                });
            }

            /**
             * Create player rackets.
             */
            gameRackets playerOneRacket = game.getPlayerOne().getRacket();
            gameRackets playerTwoRacket = game.getPlayerTwo().getRacket();

            /**
             *  Creating the balls collisions
             */
            double leftSide = ball.getBallPosX();
            double rightSide = ball.getBallPosX() + ball.getBallDimensionA();
            double topSide = ball.getBallPosY();
            double bottomSide = ball.getBallPosY() + ball.getBallDimensionB();

            /**
             *  If statements for when the ball hits a racket and increases the speed
             */
            if(leftSide <= playerOneRacket.getPosX() + playerOneRacket.getRacketWidth() && rightSide >= playerOneRacket.getPosX() && bottomSide >= playerOneRacket.getPosY() && topSide <= playerOneRacket.getPosY() + playerOneRacket.getRacketHeight()){
                ball.setVelX(-ball.getVelX() * 1.2);
            }

            if(leftSide <= playerTwoRacket.getPosX() + playerTwoRacket.getRacketWidth() && rightSide >= playerTwoRacket.getPosX() && bottomSide >= playerTwoRacket.getPosY() && topSide <= playerTwoRacket.getPosY() + playerTwoRacket.getRacketHeight()){
                ball.setVelX(-ball.getVelX() *1.2);
            }

            /**
             * Initializes the balls movement.
             */
            ball.moveBall();

            /**
             *  When a player wins the game, it will display the winners message and end the game.
             */
            if (game.gameOver() != null){
                Platform.runLater(() -> {
                    scored.setText(game.gameOver());
                    scored.setVisible(true);
                });

                pauseGame();
            }

            Platform.runLater(() -> {
                canvas.reCanvas();
            });
        }
    }
}
