package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnect {

    private static Connection dataBaseConnection;

    /**
     * Establish connection with MySQL server.
     * @return
     */
    public static Connection getConnection() {

        if(dataBaseConnection == null){
            try{
                dataBaseConnection = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/PongGame",
                        "root",
                        "root"
                );
                System.out.println("Connection Established");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return dataBaseConnection;
    }

}
