package DAO;

import Build.BuildGame;
import Model.Game;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class pongDAO {

    /**
     * Save current game to mySQL Server.
     * @param game
     */
    public void fullSave(Game game) {
        String sqlMessage = "INSERT INTO SAVED_GAMES (gameTitle,playerOneName,playerOneScore,playerTwoName,playerTwoScore,matchScore) " +  "VALUES (?, ?, ?, ?, ?, ?)";

        try(PreparedStatement statement = DatabaseConnect.getConnection().prepareStatement(sqlMessage)){

            statement.setString(1, "Pong");
            statement.setString(2, game.getPlayerOne().getPlayerUserName());
            statement.setInt(3, game.getPlayerOne().getPlayerScore());
            statement.setString(4,game.getPlayerTwo().getPlayerUserName());
            statement.setInt(5,game.getPlayerTwo().getPlayerScore());
            statement.setInt(6,game.getMatchScore());

            statement.executeUpdate();
            System.out.println("DB INSERT DONE");

        } catch (SQLException ex) {
            Logger.getLogger(pongDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Load most recent saved game from MySql Server.
     * @return
     */
    public Game loadSave(){
            String sql = "SELECT * FROM SAVED_GAMES ORDER BY gameID DESC LIMIT 1";

            try(Statement stmt = DatabaseConnect.getConnection().createStatement();
                ResultSet rs = stmt.executeQuery(sql)){

                if(rs.next()){

                    return new BuildGame()
                            .setPlayers(
                                    rs.getString("playerOneName"),
                                    rs.getString("playerTwoName")
                            )
                            .setScore(
                                    rs.getInt("playerOneScore"),
                                    rs.getInt("playerTwoScore")
                            )
                            .setMatchScore(rs.getInt("matchScore"))
                            .build();
                    }
                } catch (SQLException ex) {
                throw new RuntimeException(ex);
            }
            catch(Exception e){
                e.printStackTrace();
            }

            return null;
    }

}
